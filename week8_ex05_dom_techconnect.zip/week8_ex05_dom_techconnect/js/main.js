const developerDirectory = document.getElementById('developerDirectory');
const developerCount = document.getElementById('developerCount');
const searchInput = document.getElementById('searchInput');
const toggleViewBtn = document.getElementById('toggleViewBtn');
const addDeveloperForm = document.getElementById('addDeveloperForm');
const addFormMessage = document.getElementById('addFormMessage');
const nameError = document.getElementById('nameError');
const roleError = document.getElementById('roleError');
const skillsError = document.getElementById('skillsError');

let developers = [];
let filteredDevelopers = [];
let currentView = 'cards';
let nextDeveloperId = 16;

async function loadDevelopers() {
  try {
    const response = await fetch('./developers.json');
    if (!response.ok) {
      throw new Error('Unable to load developers data');
    }
    developers = await response.json();
    filteredDevelopers = [...developers];
    updateDeveloperCount();
    renderDirectory();
  } catch (error) {
    developerDirectory.innerHTML = '<div class="alert alert-danger">Failed to load developer data.</div>';
    console.error(error);
  }
}

function updateDeveloperCount() {
  const count = filteredDevelopers.length;
  developerCount.textContent = `${count} developer${count === 1 ? '' : 's'} found`;
}

function renderDirectory() {
  if (currentView === 'cards') {
    renderCardView();
  } else {
    renderTableView();
  }
}

function renderCardView() {
  const cards = filteredDevelopers.map((developer) => {
    const badges = developer.skills.map((skill) => `<span class="badge bg-secondary me-1 mb-1">${skill}</span>`).join('');
    const availability = developer.available
      ? '<span class="badge bg-success badge-pill">Available for Hire</span>'
      : '<span class="badge bg-secondary badge-pill">Not Available</span>';

    return `
      <div class="col-lg-4 col-md-6">
        <div class="card h-100 shadow-sm">
          <div class="card-body d-flex flex-column">
            <div class="d-flex justify-content-between align-items-start mb-3">
              <div>
                <h5 class="card-title mb-1">${developer.name}</h5>
                <p class="card-text text-muted mb-2">${developer.role}</p>
              </div>
              ${availability}
            </div>
            <div class="mb-3">
              <p class="mb-2 fw-semibold">Skills</p>
              <div>${badges}</div>
            </div>
            <p class="text-muted mb-4">Location: ${developer.location}</p>
            <button type="button" class="btn btn-outline-primary mt-auto btn-toggle-available" data-id="${developer.id}">
              Toggle Hire Badge
            </button>
          </div>
        </div>
      </div>`;
  }).join('');

  developerDirectory.innerHTML = `
    <div class="row g-4">
      ${cards}
    </div>`;
}

function renderTableView() {
  const rows = filteredDevelopers.map((developer) => {
    const availability = developer.available
      ? '<span class="badge bg-success badge-pill">Available</span>'
      : '<span class="badge bg-secondary badge-pill">Not Available</span>';

    return `
      <tr>
        <td>${developer.name}</td>
        <td>${developer.role}</td>
        <td>${developer.skills.join(', ')}</td>
        <td>${developer.location}</td>
        <td>${availability}</td>
        <td>
          <button type="button" class="btn btn-sm btn-outline-primary btn-toggle-available" data-id="${developer.id}">
            Toggle Hire Badge
          </button>
        </td>
      </tr>`;
  }).join('');

  developerDirectory.innerHTML = `
    <div class="table-responsive">
      <table class="table table-hover align-middle mb-0">
        <thead>
          <tr>
            <th>Name</th>
            <th>Role</th>
            <th>Skills</th>
            <th>Location</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          ${rows}
        </tbody>
      </table>
    </div>`;
}

function filterDevelopers(searchTerm) {
  const term = searchTerm.trim().toLowerCase();
  if (!term) {
    filteredDevelopers = [...developers];
  } else {
    filteredDevelopers = developers.filter((developer) => {
      const skillsText = developer.skills.join(' ').toLowerCase();
      return (
        developer.name.toLowerCase().includes(term) ||
        developer.role.toLowerCase().includes(term) ||
        skillsText.includes(term)
      );
    });
  }
  updateDeveloperCount();
  renderDirectory();
}

function clearFormErrors() {
  addFormMessage.textContent = '';
  addFormMessage.className = '';
  nameError.textContent = '';
  roleError.textContent = '';
  skillsError.textContent = '';
}

function validateForm(name, role, skillsArray) {
  let isValid = true;
  clearFormErrors();

  if (!name) {
    nameError.textContent = 'Name cannot be empty.';
    isValid = false;
  }

  if (!role) {
    roleError.textContent = 'Role cannot be empty.';
    isValid = false;
  }

  if (skillsArray.length === 0) {
    skillsError.textContent = 'Please add at least one skill.';
    isValid = false;
  }

  return isValid;
}

function addDeveloper(event) {
  event.preventDefault();

  const nameInput = document.getElementById('devName');
  const roleInput = document.getElementById('devRole');
  const skillsInput = document.getElementById('devSkills');
  const availableInput = document.getElementById('devAvailable');

  const name = nameInput.value.trim();
  const role = roleInput.value.trim();
  const skillsArray = skillsInput.value
    .split(',')
    .map((skill) => skill.trim())
    .filter(Boolean);
  const available = availableInput.checked;

  if (!validateForm(name, role, skillsArray)) {
    return;
  }

  const newDeveloper = {
    id: nextDeveloperId++,
    name,
    role,
    skills: skillsArray,
    available,
    location: 'Remote'
  };

  developers.unshift(newDeveloper);
  filterDevelopers(searchInput.value);
  addDeveloperForm.reset();
  clearFormErrors();
  addFormMessage.textContent = 'Developer added successfully!';
  addFormMessage.className = 'alert alert-success';
}

function handleDirectoryClick(event) {
  const button = event.target.closest('.btn-toggle-available');
  if (!button) return;

  const developerId = Number(button.dataset.id);
  const developer = developers.find((item) => item.id === developerId);
  if (!developer) return;

  developer.available = !developer.available;
  renderDirectory();
}

function toggleView() {
  currentView = currentView === 'cards' ? 'table' : 'cards';
  toggleViewBtn.textContent = currentView === 'cards' ? 'Switch to Table View' : 'Switch to Card View';
  renderDirectory();
}

searchInput.addEventListener('input', (event) => {
  filterDevelopers(event.target.value);
});

toggleViewBtn.addEventListener('click', toggleView);
addDeveloperForm.addEventListener('submit', addDeveloper);
developerDirectory.addEventListener('click', handleDirectoryClick);

loadDevelopers();
