document.addEventListener('DOMContentLoaded', function() {
  var loginForm = document.getElementById('login-form');
  if (loginForm) {
    loginForm.addEventListener('submit', function(e) {
      e.preventDefault();
      validateLogin();
    });
  }
});

function validateLogin() {
  var unameEl = document.getElementById('uname');
  var pwdEl = document.getElementById('pwd');
  var username = unameEl ? unameEl.value.trim() : '';
  var password = pwdEl ? pwdEl.value : '';

  if (username === 'admin' && password === 'password123') {
    window.location.href = 'index.html';
    return;
  }

  console.log('Invalid credentials');
  var modal = document.querySelector('.modal');
  if (modal) modal.style.display = 'block';
}

function dismissModal() {
  var modal = document.querySelector('.modal');
  if (modal) modal.style.display = 'none';
}

function toggleNav() {
  var sidebar = document.querySelector('.nav-sidebar');
  if (!sidebar) return;
  var ul = sidebar.querySelector('ul');
  var computed = window.getComputedStyle(sidebar);
  var width = parseInt(computed.width, 10);

  if (width <= 60) {
    sidebar.style.width = '250px';
    if (ul) {
      ul.style.visibility = 'visible';
      ul.style.overflow = 'visible';
    }
  } else {
    sidebar.style.width = '50px';
    if (ul) {
      ul.style.visibility = 'hidden';
      ul.style.overflow = 'hidden';
    }
  }
}
